import pandas as pd
import joblib

# Load model and encoders
model = joblib.load("model.pkl")
label_encoder = joblib.load("label_encoder.pkl")

# Load demo.csv just to get column order (excluding label)
full_df = pd.read_csv("demo.csv")
expected_columns = full_df.drop(columns=["label"]).columns.tolist()

# Sample test input (you can change these values)
input_data = pd.DataFrame([{
    "duration": 5,
    "protocol_type": "tcp",
    "service": "http",
    "src_bytes": 600,
    "dst_bytes": 1200,
    "flag": "SF",
    "land": 0,
    "wrong_fragment": 0,
    "urgent": 0
}])

# Ensure column order matches
input_data = input_data[expected_columns]

# Encode any categorical columns using saved encoders
for col in input_data.columns:
    try:
        encoder = joblib.load(f"{col}_encoder.pkl")
        input_data[col] = encoder.transform(input_data[col])
    except:
        continue

# Predict and decode
pred = model.predict(input_data)[0]
predicted_label = label_encoder.inverse_transform([pred])[0]
print(f"Predicted class: {predicted_label}")
