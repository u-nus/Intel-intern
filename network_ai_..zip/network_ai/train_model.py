import pandas as pd
import joblib
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import classification_report

# Load and clean dataset
df = pd.read_csv("demo.csv")
df.columns = df.columns.str.strip()

if "label" not in df.columns:
    raise ValueError("Your dataset must contain a 'label' column!")

X = df.drop(columns=["label"])
y = df["label"]

# Encode categorical features
for col in X.columns:
    if X[col].dtype == 'object':
        encoder = LabelEncoder()
        X[col] = encoder.fit_transform(X[col])
        joblib.dump(encoder, f"{col}_encoder.pkl")

# Encode target
label_encoder = LabelEncoder()
y = label_encoder.fit_transform(y)
joblib.dump(label_encoder, "label_encoder.pkl")

# Train/test split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train model
model = RandomForestClassifier(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

# Evaluate
print("\n Evaluation Report:")
print(classification_report(y_test, model.predict(X_test)))

# Save model
joblib.dump(model, "model.pkl")
print("\n Model trained and saved as model.pkl")